import requests
import datetime
import time
from bs4 import BeautifulSoup
import os
import fitz  # PyMuPDF
import telebot

# === Telegram Bot Config ===
BOT_TOKEN = "7713344673:AAHFUC7NewiLGqrghcJYIDsrPUwwPMYZajQ"
CHAT_ID = None  # Filled when someone starts the bot

bot = telebot.TeleBot(BOT_TOKEN)

# === BSE Scraper Config ===
BSE_URL = "https://www.bseindia.com/corporates/ann.html"
BASE_DOC_URL = "https://www.bseindia.com"

def get_yesterday_date():
    return (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%d/%m/%Y")

def fetch_announcements():
    headers = {
        "User-Agent": "Mozilla/5.0",
    }
    session = requests.Session()

    yesterday = get_yesterday_date()
    params = {
        "strFromDate": yesterday,
        "strToDate": yesterday,
        "category": "C",
        "subCategory": "101",
    }

    response = session.post(BSE_URL, data=params, headers=headers)
    soup = BeautifulSoup(response.content, "html.parser")
    table = soup.find("table", {"id": "ann1"})

    announcements = []
    if table:
        for row in table.find_all("tr")[1:]:
            cols = row.find_all("td")
            if len(cols) >= 5:
                company = cols[0].get_text(strip=True)
                pdf_link = cols[4].find("a")
                if pdf_link:
                    full_link = BASE_DOC_URL + pdf_link.get("href")
                    announcements.append((company, full_link))
    return announcements

def download_pdf(url):
    response = requests.get(url)
    filename = "/tmp/temp.pdf"
    with open(filename, "wb") as f:
        f.write(response.content)
    return filename

def extract_order_value_from_pdf(pdf_path):
    text = ""
    with fitz.open(pdf_path) as doc:
        for page in doc:
            text += page.get_text()

    company_name = ""
    value_line = ""
    for line in text.split("\n"):
        if "order" in line.lower() and "value" in line.lower():
            value_line = line.strip()
        if "company" in line.lower():
            company_name = line.strip()

    return value_line or "Not found"

def get_daily_report():
    report_lines = []
    announcements = fetch_announcements()
    if not announcements:
        return "No announcements found for yesterday."

    for company, pdf_url in announcements:
        try:
            pdf_path = download_pdf(pdf_url)
            value_info = extract_order_value_from_pdf(pdf_path)
            report_lines.append(f"{company}: {value_info}")
        except Exception as e:
            report_lines.append(f"{company}: Failed to read PDF")
    return "\n".join(report_lines)

@bot.message_handler(commands=['start'])
def handle_start(message):
    global CHAT_ID
    CHAT_ID = message.chat.id
    bot.send_message(CHAT_ID, "Fetching yesterday's BSE order updates...")
    report = get_daily_report()
    bot.send_message(CHAT_ID, report)

if __name__ == "__main__":
    bot.polling()
